package cscorner;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BoxPriceCalculator extends JFrame {
    private JTextField lengthField;
    private JTextField widthField;
    private JTextField pricePerUnitField;
    private JTextField userNameField;
    private JTextField dateField;
    private JTextArea resultArea;
    private JButton calculateButton;
    private JButton dateButton;
    private JButton saveBillButton;
    private JButton addItemButton;
    private JButton clearItemsButton;
    
    private List<BoxItem> items = new ArrayList<>();
    private double totalPrice = 0.0;
    
    public BoxPriceCalculator() {
        // Set up the GUI
        setTitle("Box Price Calculator");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        
        // Create input panel
        JPanel inputPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        
        // Add components to input panel
        inputPanel.add(new JLabel("User Name:"));
        userNameField = new JTextField();
        inputPanel.add(userNameField);
        
        inputPanel.add(new JLabel("Date:"));
        JPanel datePanel = new JPanel(new BorderLayout());
        dateField = new JTextField();
        dateField.setEditable(false);
        dateButton = new JButton("Today");
        dateButton.addActionListener(e -> setCurrentDate());
        datePanel.add(dateField, BorderLayout.CENTER);
        datePanel.add(dateButton, BorderLayout.EAST);
        inputPanel.add(datePanel);
        
        inputPanel.add(new JLabel("Box Length (units):"));
        lengthField = new JTextField();
        inputPanel.add(lengthField);
        
        inputPanel.add(new JLabel("Box Width (units):"));
        widthField = new JTextField();
        inputPanel.add(widthField);
        
        inputPanel.add(new JLabel("Price per Unit Area (₹):"));
        pricePerUnitField = new JTextField("20"); // Default price of ₹20
        inputPanel.add(pricePerUnitField);
        
        // Create button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        calculateButton = new JButton("Calculate Item");
        calculateButton.addActionListener(e -> calculateItem());
        buttonPanel.add(calculateButton);
        
        addItemButton = new JButton("Add to Bill");
        addItemButton.addActionListener(e -> addItemToBill());
        buttonPanel.add(addItemButton);
        
        clearItemsButton = new JButton("Clear All Items");
        clearItemsButton.addActionListener(e -> clearAllItems());
        buttonPanel.add(clearItemsButton);
        
        saveBillButton = new JButton("Save Bill");
        saveBillButton.addActionListener(e -> saveBill());
        buttonPanel.add(saveBillButton);
        
        // Create result area
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(resultArea);
        
        // Add panels to frame
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
        
        // Add padding
        ((JComponent) getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Set current date by default
        setCurrentDate();
        updateResultArea();
    }
    
    private void setCurrentDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        dateField.setText(dateFormat.format(new Date()));
    }
    
    private void calculateItem() {
        try {
            if (lengthField.getText().trim().isEmpty() || 
                widthField.getText().trim().isEmpty() || 
                pricePerUnitField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            double length = Double.parseDouble(lengthField.getText());
            double width = Double.parseDouble(widthField.getText());
            double pricePerUnit = Double.parseDouble(pricePerUnitField.getText());
            
            double area = length * width;
            double total = area * pricePerUnit;
            
            String result = String.format("Current Item: %.1f × %.1f = %.1f sq units @ ₹%.2f = ₹%.2f", 
                length, width, area, pricePerUnit, total);
            
            resultArea.setText(result);
        } catch (NumberFormatException ex) {
            resultArea.setText("Please enter valid numbers for dimensions and price");
        }
    }
    
    private void addItemToBill() {
        try {
            if (lengthField.getText().trim().isEmpty() || 
                widthField.getText().trim().isEmpty() || 
                pricePerUnitField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            double length = Double.parseDouble(lengthField.getText());
            double width = Double.parseDouble(widthField.getText());
            double pricePerUnit = Double.parseDouble(pricePerUnitField.getText());
            
            BoxItem item = new BoxItem(length, width, pricePerUnit);
            items.add(item);
            totalPrice += item.getTotalPrice();
            
            updateResultArea();
            
            // Clear fields for next entry
            lengthField.setText("");
            widthField.setText("");
            pricePerUnitField.setText("20");
            lengthField.requestFocus();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for dimensions and price", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void clearAllItems() {
        items.clear();
        totalPrice = 0.0;
        updateResultArea();
    }
    
    private void updateResultArea() {
        StringBuilder sb = new StringBuilder();
        
        if (items.isEmpty()) {
            sb.append("No items in the bill yet.\n");
        } else {
            sb.append("==================== CURRENT BILL ====================\n");
            sb.append(String.format("%-5s %-15s %-15s %-15s %-15s\n", 
                "No.", "Dimensions", "Area", "Unit Price", "Item Total"));
            sb.append("----------------------------------------------------\n");
            
            for (int i = 0; i < items.size(); i++) {
                BoxItem item = items.get(i);
                sb.append(String.format("%-5d %-15s %-15.1f ₹%-14.2f ₹%-14.2f\n", 
                    i + 1, 
                    item.getLength() + " × " + item.getWidth(), 
                    item.getArea(), 
                    item.getPricePerUnit(), 
                    item.getTotalPrice()));
            }
            
            sb.append("----------------------------------------------------\n");
            sb.append(String.format("%54s ₹%.2f\n", "TOTAL:", totalPrice));
        }
        
        resultArea.setText(sb.toString());
    }
    
    private void saveBill() {
        try {
            String userName = userNameField.getText().trim();
            if (userName.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter your name first", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (items.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No items to save. Please add items to the bill first.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Create a file chooser
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Save Bill As");
            
            // Set default file name with username and date
            String sanitizedUsername = userName.replaceAll("[^a-zA-Z0-9]", "_");
            String datePart = dateField.getText().replace("/", "-");
            String defaultFileName = String.format("%s_BoxBill_%s.txt", sanitizedUsername, datePart);
            fileChooser.setSelectedFile(new File(defaultFileName));
            
            // Show save dialog
            int userSelection = fileChooser.showSaveDialog(this);
            
            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                String filePath = fileToSave.getAbsolutePath();
                
                // Ensure .txt extension if not provided
                if (!filePath.toLowerCase().endsWith(".txt")) {
                    fileToSave = new File(filePath + ".txt");
                }
                
                // Write bill to file
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave))) {
                    writer.write("==================== EAGLE GRAPHIC BILL ====================\n");
                    writer.write("Customer Name: " + userName + "\n");
                    writer.write("Date: " + dateField.getText() + "\n");
                    writer.write("-------------------------------------------------\n");
                    writer.write(String.format("%-5s %-15s %-15s %-15s %-15s\n", 
                        "No.", "Dimensions", "Area", "Unit Price", "Item Total"));
                    writer.write("-------------------------------------------------\n");
                    
                    for (int i = 0; i < items.size(); i++) {
                        BoxItem item = items.get(i);
                        writer.write(String.format("%-5d %-15s %-15.1f ₹%-14.2f ₹%-14.2f\n", 
                            i + 1, 
                            item.getLength() + " × " + item.getWidth(), 
                            item.getArea(), 
                            item.getPricePerUnit(), 
                            item.getTotalPrice()));
                    }
                    
                    writer.write("-------------------------------------------------\n");
                    writer.write(String.format("%54s ₹%.2f\n", "TOTAL:", totalPrice));
                    writer.write("=================== THANK YOU ===================\n");
                    
                    JOptionPane.showMessageDialog(this, 
                        "Bill saved successfully to:\n" + fileToSave.getAbsolutePath(), 
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, 
                        "Error saving bill: " + e.getMessage(), 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error: " + e.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private class BoxItem {
        private double length;
        private double width;
        private double pricePerUnit;
        
        public BoxItem(double length, double width, double pricePerUnit) {
            this.length = length;
            this.width = width;
            this.pricePerUnit = pricePerUnit;
        }
        
        public double getLength() { return length; }
        public double getWidth() { return width; }
        public double getPricePerUnit() { return pricePerUnit; }
        public double getArea() { return length * width; }
        public double getTotalPrice() { return getArea() * pricePerUnit; }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BoxPriceCalculator calculator = new BoxPriceCalculator();
            calculator.setVisible(true);
        });
    }
}